require('dotenv').config();

const express = require('express');
const path = require('path');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const helmet = require('helmet');
const { rateLimit } = require('express-rate-limit');

const db = require('../database/db');
const aiService = require('../services/aiService');

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const isProduction = process.env.NODE_ENV === 'production';
const sessionSecret = process.env.SESSION_SECRET;
const maxPromptLength = Math.min(
  Math.max(Number(process.env.MAX_PROMPT_LENGTH) || 12000, 100),
  30000
);

if (!sessionSecret || sessionSecret.length < 32) {
  console.error('SESSION_SECRET must be set to a random value of at least 32 characters.');
  process.exit(1);
}

if (process.env.TRUST_PROXY === '1') {
  // Use only when deployed behind a trusted reverse proxy.
  app.set('trust proxy', 1);
}

app.disable('x-powered-by');

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", 'data:'],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      frameAncestors: ["'none'"],
      upgradeInsecureRequests: isProduction ? [] : null
    }
  }
}));

app.use(express.json({ limit: '64kb' }));

app.use(session({
  name: 'nebras.sid',
  store: new SQLiteStore({
    db: 'sessions.sqlite',
    dir: path.join(__dirname, '../database')
  }),
  secret: sessionSecret,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'strict',
    secure: isProduction,
    maxAge: 7 * 24 * 60 * 60 * 1000
  }
}));

app.use(express.static(path.join(__dirname, '../public')));

const chatLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 12,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: 'تجاوزت عدد الطلبات المسموح بها مؤقتاً. انتظر دقيقة ثم حاول.' }
});

function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (error) {
      if (error) reject(error);
      else resolve(this);
    });
  });
}

function all(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (error, rows) => {
      if (error) reject(error);
      else resolve(rows);
    });
  });
}

function ensureSession(req, res, next) {
  if (!req.session) {
    return res.status(500).json({ error: 'تعذر إنشاء جلسة آمنة.' });
  }

  // Important: saveUninitialized=false means an untouched guest session is not
  // persisted. This marker ensures the browser receives a stable session cookie.
  if (!req.session.nebrasInitialized) {
    req.session.nebrasInitialized = true;
  }
  next();
}

app.get('/api/health', async (req, res) => {
  try {
    await db.ready;
    res.json({
      status: 'ok',
      version: '3.3.2',
      name: 'NEBRAS AI',
      database: 'connected',
      aiConfigured: Boolean(
        process.env.GEMINI_API_KEY &&
        process.env.GEMINI_API_KEY !== 'put_your_real_key_here'
      )
    });
  } catch (error) {
    console.error('Health check database error:', error.message);
    res.status(503).json({ status: 'error', database: 'unavailable' });
  }
});

app.get('/api/messages', ensureSession, async (req, res, next) => {
  try {
    await db.ready;
    const rows = await all(
      'SELECT id, role, content, timestamp FROM messages WHERE session_id = ? ORDER BY id DESC LIMIT 50',
      [req.sessionID]
    );
    res.json({ messages: rows.reverse() });
  } catch (error) {
    next(error);
  }
});

app.post('/api/chat', ensureSession, chatLimiter, async (req, res, next) => {
  const prompt = typeof req.body?.prompt === 'string' ? req.body.prompt.trim() : '';

  if (!prompt) {
    return res.status(400).json({ error: 'اكتب رسالتك أولاً.' });
  }
  if (prompt.length > maxPromptLength) {
    return res.status(413).json({ error: `الرسالة طويلة جداً. الحد الأقصى ${maxPromptLength} حرف.` });
  }

  try {
    await db.ready;

    const previous = await all(
      'SELECT role, content FROM messages WHERE session_id = ? ORDER BY id DESC LIMIT 12',
      [req.sessionID]
    );

    const history = previous.reverse().map(row => ({
      role: row.role,
      content: row.content
    }));

    const result = await aiService.generateResponse(history, prompt);
    const answer = result.answer;

    await run(
      'INSERT INTO messages (session_id, role, content) VALUES (?, ?, ?)',
      [req.sessionID, 'user', prompt]
    );
    const savedAnswer = await run(
      'INSERT INTO messages (session_id, role, content) VALUES (?, ?, ?)',
      [req.sessionID, 'assistant', answer]
    );

    // Keep a bounded history per guest session to prevent unlimited DB growth.
    await run(
      `DELETE FROM messages
       WHERE session_id = ?
       AND id NOT IN (
         SELECT id FROM messages WHERE session_id = ? ORDER BY id DESC LIMIT 200
       )`,
      [req.sessionID, req.sessionID]
    );

    res.json({ success: true, response: answer, messageId: savedAnswer.lastID, providers: result.providers });
  } catch (error) {
    next(error);
  }
});

app.post('/api/feedback', ensureSession, async (req, res, next) => {
  try {
    const messageId = Number(req.body?.messageId);
    const rating = req.body?.rating;
    if (!Number.isSafeInteger(messageId) || messageId < 1 || !['like', 'dislike'].includes(rating)) {
      return res.status(400).json({ error: 'بيانات التقييم غير صحيحة.' });
    }
    await db.ready;
    const owned = await all(
      "SELECT id FROM messages WHERE id = ? AND session_id = ? AND role = 'assistant'",
      [messageId, req.sessionID]
    );
    if (!owned.length) return res.status(404).json({ error: 'الإجابة غير موجودة في هذه المحادثة.' });
    await run(
      `INSERT INTO feedback (message_id, session_id, rating) VALUES (?, ?, ?)
       ON CONFLICT(message_id) DO UPDATE SET rating = excluded.rating`,
      [messageId, req.sessionID, rating]
    );
    res.json({ success: true });
  } catch (error) { next(error); }
});

app.delete('/api/messages', ensureSession, async (req, res, next) => {
  try {
    await db.ready;
    await run('DELETE FROM messages WHERE session_id = ?', [req.sessionID]);
    res.json({ success: true });
  } catch (error) {
    next(error);
  }
});

app.use((req, res) => {
  res.status(404).json({ error: 'المسار المطلوب غير موجود.' });
});

app.use((error, req, res, next) => {
  if (res.headersSent) return next(error);

  console.error('Request error:', error.message);
  if (error.providerMessage) {
    console.error('Gemini provider detail:', error.providerMessage);
  }

  const status = Number.isInteger(error.status) ? error.status : 500;
  if (status === 400 && error.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'صيغة البيانات المرسلة غير صحيحة.' });
  }

  const publicMessage = status >= 500 && status !== 503
    ? 'حدث خطأ في الخادم. حاول لاحقاً.'
    : error.message;

  res.status(status).json({ error: publicMessage });
});

async function start() {
  await db.ready;
  const server = app.listen(PORT, () => {
    console.log(`NEBRAS AI 3.3.1 is running on port ${PORT}`);
  });

  const shutdown = () => {
    server.close(() => {
      db.close((error) => {
        if (error) console.error('Database close error:', error.message);
        process.exit(error ? 1 : 0);
      });
    });
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

start().catch((error) => {
  console.error('NEBRAS AI failed to start:', error.message);
  process.exit(1);
});

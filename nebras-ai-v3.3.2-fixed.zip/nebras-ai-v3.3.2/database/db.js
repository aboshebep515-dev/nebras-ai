const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

const configuredPath = process.env.DB_PATH || './database/nebras.db';
const dbPath = path.isAbsolute(configuredPath)
  ? configuredPath
  : path.resolve(process.cwd(), configuredPath);

fs.mkdirSync(path.dirname(dbPath), { recursive: true });

const db = new sqlite3.Database(dbPath);
db.ready = new Promise((resolve, reject) => {
  db.serialize(() => {
    db.run('PRAGMA foreign_keys = ON', (pragmaError) => {
      if (pragmaError) return reject(pragmaError);
      db.run(`
        CREATE TABLE IF NOT EXISTS messages (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          session_id TEXT NOT NULL,
          role TEXT NOT NULL CHECK(role IN ('user', 'assistant')),
          content TEXT NOT NULL,
          timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
      `, (tableError) => {
        if (tableError) return reject(tableError);
        db.run(
          'CREATE INDEX IF NOT EXISTS idx_messages_session_id_id ON messages(session_id, id)',
          (indexError) => {
            if (indexError) return reject(indexError);
            db.run(`CREATE TABLE IF NOT EXISTS feedback (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              message_id INTEGER NOT NULL UNIQUE,
              session_id TEXT NOT NULL,
              rating TEXT NOT NULL CHECK(rating IN ('like', 'dislike')),
              created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY(message_id) REFERENCES messages(id) ON DELETE CASCADE
            )`, (feedbackError) => feedbackError ? reject(feedbackError) : resolve());
          }
        );
      });
    });
  });
});

module.exports = db;

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('chat-form');
  const input = document.getElementById('user-input');
  const messages = document.getElementById('chat-messages');
  const sendButton = document.getElementById('send-button');
  const clearButton = document.getElementById('clear-chat');
  let busy = false;
  let historyReady = false;

  function appendMessage(role, text, extraClass = '', messageId = null) {
    document.getElementById('welcome')?.remove();
    const wrap = document.createElement('div');
    wrap.className = `message-wrap ${role}-wrap`;
    const item = document.createElement('div');
    item.className = `message ${role} ${extraClass}`.trim();
    item.textContent = text;
    wrap.appendChild(item);

    if (role === 'assistant' && messageId) {
      const actions = document.createElement('div');
      actions.className = 'feedback-actions';
      const like = document.createElement('button');
      like.type = 'button'; like.textContent = '👍 إعجاب'; like.setAttribute('aria-label', 'إعجاب بالإجابة');
      const dislike = document.createElement('button');
      dislike.type = 'button'; dislike.textContent = '👎 لم يعجبني'; dislike.setAttribute('aria-label', 'لم تعجبني الإجابة');
      async function rate(rating, selected) {
        like.disabled = dislike.disabled = true;
        try {
          const r = await fetch('/api/feedback', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ messageId, rating })
          });
          const d = await r.json().catch(() => ({}));
          if (!r.ok || !d.success) throw new Error(d.error || 'تعذر حفظ التقييم');
          like.classList.toggle('selected', selected === like);
          dislike.classList.toggle('selected', selected === dislike);
          like.disabled = dislike.disabled = false;
        } catch (e) {
          like.disabled = dislike.disabled = false;
          appendMessage('assistant', e.message, 'error');
        }
      }
      like.addEventListener('click', () => rate('like', like));
      dislike.addEventListener('click', () => rate('dislike', dislike));
      actions.append(like, dislike);
      wrap.appendChild(actions);
    }
    messages.appendChild(wrap);
    messages.scrollTop = messages.scrollHeight;
    return wrap;
  }

  function setBusy(value) {
    busy = value;
    sendButton.disabled = value || !historyReady;
    input.disabled = value || !historyReady;
    sendButton.textContent = value ? '…' : '➤';
  }

  async function loadHistory() {
    try {
      const response = await fetch('/api/messages', { credentials: 'same-origin' });
      if (!response.ok) throw new Error('تعذر تحميل سجل المحادثة.');
      const data = await response.json();
      if (Array.isArray(data.messages) && data.messages.length) {
        document.getElementById('welcome')?.remove();
        data.messages.forEach(message => appendMessage(message.role, message.content, '', message.id));
      }
    } catch (error) {
      appendMessage('assistant', error.message || 'تعذر تحميل المحادثة السابقة.', 'error');
    } finally {
      historyReady = true;
      setBusy(false);
      input.focus();
    }
  }

  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (busy || !historyReady) return;

    const prompt = input.value.trim();
    if (!prompt) return;

    appendMessage('user', prompt);
    input.value = '';
    input.style.height = 'auto';

    const typing = appendMessage('assistant', 'نبراس يكتب الآن…', 'typing');
    setBusy(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt })
      });
      const data = await response.json().catch(() => ({}));
      typing.remove();

      if (!response.ok || !data.success) {
        throw new Error(data.error || 'تعذر إكمال الطلب.');
      }
      appendMessage('assistant', data.response, '', data.messageId);
    } catch (error) {
      typing.remove();
      appendMessage('assistant', error.message || 'تعذر الاتصال بالخادم.', 'error');
    } finally {
      setBusy(false);
      input.focus();
    }
  });

  input.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = `${Math.min(input.scrollHeight, 180)}px`;
  });

  input.addEventListener('keydown', event => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      form.requestSubmit();
    }
  });

  clearButton.addEventListener('click', async () => {
    if (busy || !historyReady || !confirm('هل تريد مسح سجل هذه المحادثة؟')) return;

    clearButton.disabled = true;
    try {
      const response = await fetch('/api/messages', {
        method: 'DELETE',
        credentials: 'same-origin'
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data.success) {
        throw new Error(data.error || 'تعذر مسح المحادثة.');
      }

      messages.replaceChildren();
      const welcome = document.createElement('section');
      welcome.id = 'welcome';
      welcome.className = 'welcome';
      const icon = document.createElement('div');
      icon.className = 'welcome-icon';
      icon.textContent = '✦';
      const heading = document.createElement('h2');
      heading.textContent = 'أهلاً بك في نبراس';
      const paragraph = document.createElement('p');
      paragraph.textContent = 'كيف يمكنني مساعدتك اليوم؟';
      welcome.append(icon, heading, paragraph);
      messages.appendChild(welcome);
    } catch (error) {
      appendMessage('assistant', error.message || 'تعذر مسح المحادثة.', 'error');
    } finally {
      clearButton.disabled = false;
    }
  });

  input.disabled = true;
  sendButton.disabled = true;
  loadHistory();
});

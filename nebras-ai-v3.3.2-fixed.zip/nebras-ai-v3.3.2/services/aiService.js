const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini';
const GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/models';

async function withTimeout(url, options, ms = 45000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  try { return await fetch(url, { ...options, signal: controller.signal }); }
  finally { clearTimeout(timer); }
}

async function askGemini(history, prompt) {
  const key = process.env.GEMINI_API_KEY;
  if (!key || key === 'put_your_real_key_here') throw new Error('Gemini غير مهيأ');
  const contents = [
    ...history.map(m => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] })),
    { role: 'user', parts: [{ text: prompt }] }
  ];
  const r = await withTimeout(`${GEMINI_URL}/${encodeURIComponent(GEMINI_MODEL)}:generateContent`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
    body: JSON.stringify({
      contents,
      systemInstruction: { parts: [{ text: 'أنت نبراس AI، مساعد عربي دقيق. أجب بوضوح، وصرّح بعدم اليقين ولا تدّع تنفيذ ما لم تنفذه.' }] },
      generationConfig: { temperature: 0.7, maxOutputTokens: 2048 }
    })
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(`Gemini HTTP ${r.status}`);
  const answer = data?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('').trim();
  if (!answer) throw new Error('Gemini لم يرجع إجابة نصية');
  return answer;
}

async function askOpenAI(history, prompt) {
  const key = process.env.OPENAI_API_KEY;
  if (!key || key === 'put_your_openai_key_here') throw new Error('OpenAI غير مهيأ');
  const messages = [
    { role: 'system', content: 'أنت نبراس AI، مساعد عربي دقيق. أجب بوضوح، وصرّح بعدم اليقين ولا تدّع تنفيذ ما لم تنفذه.' },
    ...history.map(m => ({ role: m.role, content: m.content })),
    { role: 'user', content: prompt }
  ];
  const r = await withTimeout('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
    body: JSON.stringify({ model: OPENAI_MODEL, messages, temperature: 0.7, max_tokens: 2048 })
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(`OpenAI HTTP ${r.status}`);
  const answer = data?.choices?.[0]?.message?.content?.trim();
  if (!answer) throw new Error('OpenAI لم يرجع إجابة نصية');
  return answer;
}

class AIService {
  async generateResponse(history, prompt) {
    const configured = [
      ['ChatGPT', process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY !== 'put_your_openai_key_here', askOpenAI],
      ['Gemini', process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'put_your_real_key_here', askGemini]
    ].filter(x => x[1]);

    if (!configured.length) {
      const e = new Error('لم يتم إعداد مفاتيح OpenAI وGemini على الخادم. أضف مفتاحاً واحداً على الأقل إلى إعدادات البيئة.');
      e.status = 503; throw e;
    }

    const results = await Promise.allSettled(configured.map(x => x[2](history, prompt)));
    const successful = results.map((r, i) => r.status === 'fulfilled'
      ? { name: configured[i][0], answer: r.value } : null).filter(Boolean);

    if (!successful.length) {
      const e = new Error('تعذر الاتصال بخدمات الذكاء الاصطناعي. تحقق من مفاتيح API والاتصال ثم حاول مجدداً.');
      e.status = 502; throw e;
    }

    if (successful.length === 1) {
      return { answer: successful[0].answer, providers: [successful[0].name] };
    }

    return {
      answer: `إجابة ChatGPT:\n${successful.find(x => x.name === 'ChatGPT').answer}\n\n━━━━━━━━━━━━━━\n\nإجابة Gemini:\n${successful.find(x => x.name === 'Gemini').answer}`,
      providers: successful.map(x => x.name)
    };
  }
}
module.exports = new AIService();
